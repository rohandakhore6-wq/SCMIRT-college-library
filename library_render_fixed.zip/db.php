<?php
// Configure these as environment variables in Render.
// Do not commit real database credentials to a public repository.
$host = getenv('DB_HOST') ?: 'localhost';
$user = getenv('DB_USER') ?: 'root';
$password = getenv('DB_PASSWORD') ?: '';
$database = getenv('DB_NAME') ?: 'library';

mysqli_report(MYSQLI_REPORT_OFF);
$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    error_log('Database connection failed: ' . mysqli_connect_error());
    http_response_code(500);
    die('Database connection failed. Please check the hosting database settings.');
}

mysqli_set_charset($conn, 'utf8mb4');
?>
