<?php
session_start();
include '../db.php';
?>

<html>
<head>
<title>Issued Books</title>

<style>
body{
 font-family:Arial;
 background:#f4f6f9;
 margin:0;
}

.container{
 padding:30px;
}

table{
 width:95%;
 background:white;
 border-collapse:collapse;
 margin:auto;
 box-shadow:0 0 20px rgba(0,0,0,0.3);
}

th{
 background:#2196F3;
 color:white;
}

th,td{
 padding:12px;
 border:1px solid #ccc;
 text-align:center;
}
</style>
</head>

<body>

<div class="container">

<h1 align="center">📖 Issued Books</h1>

<table>

<tr>
<th>Student Name</th>
<th>Book Title</th>
<th>Issue Date</th>
<th>Due Date</th>
<th>Return Date</th>
<th>Status</th>
<th>Fine (₹)</th>
</tr>

<?php
$q = mysqli_query($conn,
"SELECT i.*, s.student_name, b.book_name
FROM issued_books i
JOIN students s ON i.student_id = s.student_id
JOIN books b ON i.book_id = b.book_id
ORDER BY i.id DESC");

if($q && mysqli_num_rows($q)>0){

while($row = mysqli_fetch_assoc($q)){

$today = date("Y-m-d");
$due = $row['due_date'];

$fine = 0;

if($today > $due && $row['status'] != 'Returned'){
 $days = (strtotime($today) - strtotime($due)) / (60*60*24);
 $fine = $days * 5;
}

echo "<tr>
<td>{$row['student_name']}</td>
<td>{$row['book_name']}</td>
<td>{$row['issue_date']}</td>
<td>{$row['due_date']}</td>
<td>".($row['return_date'] ?? '-')."</td>
<td>{$row['status']}</td>
<td style='color:".($fine>0?"red":"green").";font-weight:bold;'>₹ $fine</td>
</tr>";
}

}else{
 echo "<tr><td colspan='7'>No issued books found 📭</td></tr>";
}
?>

</table>

<br>
<a href="dashboard.php">⬅ Back to Dashboard</a>

</div>

</body>
</html>