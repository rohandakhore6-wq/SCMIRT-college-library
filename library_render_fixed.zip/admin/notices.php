<?php
include '../db.php';
?>

<html>
<head>
<title>Library Notices</title>

<style>
body{
 font-family:Arial;
 background:#f2f2f2;
 margin:0;
}

.box{
 background:white;
 padding:25px;
 width:400px;
 margin:40px auto;
 border-radius:10px;
 box-shadow:0 0 15px rgba(0,0,0,0.2);
 text-align:center;
}

textarea{
 width:95%;
 height:100px;
 padding:10px;
 margin:10px 0;
 border-radius:6px;
}

button{
 padding:10px;
 background:#0072ff;
 color:white;
 border:none;
 border-radius:6px;
 width:100%;
 cursor:pointer;
}

.notice{
 background:white;
 padding:15px;
 margin:15px auto;
 width:70%;
 border-radius:8px;
 box-shadow:0 0 10px rgba(0,0,0,0.2);
}
</style>
</head>

<body>

<div class="box">

<h2>📢 Add Notice</h2>

<form method="post">

<textarea name="msg" placeholder="Enter notice..." required></textarea>

<button name="add">Post Notice</button>

</form>

</div>

<?php
// 🔥 ADD NOTICE + SEND TO ALL STUDENTS
if(isset($_POST['add'])){
$m = $_POST['msg'];

// ✅ 1. Save in notices table
mysqli_query($conn,
"INSERT INTO notices(message) VALUES('$m')");

// ✅ 2. Send to all students (notifications table)
$students = mysqli_query($conn,"SELECT student_id FROM students");

while($s = mysqli_fetch_assoc($students)){

 $sid = $s['student_id'];

 mysqli_query($conn,
 "INSERT INTO notifications (student_id, message)
 VALUES ('$sid', '$m')");
}

echo "<script>alert('✔️ Notice sent to all students');</script>";
}
?>

<h2 align="center">All Notices</h2>

<?php
$n = mysqli_query($conn,
"SELECT * FROM notices ORDER BY id DESC");

while($row = mysqli_fetch_assoc($n)){
echo "<div class='notice'>
<b>{$row['message']}</b><br>
<small>📅 ".date("d-m-Y h:i A", strtotime($row['created_at']))."</small>
</div>";
}
?>

</body>
</html>