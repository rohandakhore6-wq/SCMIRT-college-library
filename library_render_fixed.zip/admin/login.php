<?php include '../db.php'; ?>
<html>
<head>
<title>Admin Login</title>

<style>
body{
 background: url('../images/bg.jpg') no-repeat center center/cover;
 font-family: Arial, sans-serif;
 margin:0;
 height:100vh;
 display:flex;
 justify-content:center;
 align-items:center;
}

/* BOX */
.box{
 background: rgba(255,255,255,0.22);
 padding:45px;
 width:360px;
 border-radius:18px;
 box-shadow:0 0 45px rgba(0,0,0,0.5);
 backdrop-filter: blur(12px);
 text-align:center;
 border:1px solid rgba(255,255,255,0.6);
}

/* HEADING */
.heading{
 font-size:28px;
 font-weight:bold;
 margin-bottom:25px;
 color:white;
 text-shadow:0 0 10px rgba(0,0,0,0.9);
}

/* INPUT */
input{
 width:90%;
 padding:12px;
 margin:10px 0;
 border-radius:8px;
 border:none;
 font-size:16px;
}

/* BUTTON */
button{
 width:95%;
 padding:12px;
 background:#ff5e62;
 color:white;
 border:none;
 border-radius:8px;
 font-size:18px;
 cursor:pointer;
 margin-top:10px;
}

button:hover{
 background:#d94348;
}

a{
 display:block;
 margin-top:15px;
 color:white;
 text-decoration:none;
}
</style>
</head>

<body>

<div class="box">

<div class="heading">👨‍💼 Admin Login</div>

<form method="post">

<input type="text" name="u" placeholder="Username" required>

<input type="password" name="p" placeholder="Password" required>

<button name="login">Login</button>

</form>

<?php
if(isset($_POST['login'])){
$u=$_POST['u'];
$p=$_POST['p'];

$q=mysqli_query($conn,"SELECT * FROM admin 
WHERE username='$u' AND password='$p'");

if(mysqli_num_rows($q)>0){
 header("Location: dashboard.php");
}else{
 echo "<script>alert('Invalid Admin Login ❌');</script>";
}
}
?>

<a href="../index.php">⬅ Back</a>

</div>

</body>
</html>
