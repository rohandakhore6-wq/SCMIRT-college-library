<?php
session_start();
include '../db.php';

$total = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(amount) as total FROM payment WHERE status IN('paid','approved')
"))['total'] ?? 0;

$pending = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT SUM(amount) as pending FROM payment WHERE status='pending'
"))['pending'] ?? 0;
?>

<html>
<head>
<title>Admin Dashboard</title>

<style>
body{
 margin:0;
 font-family:Arial;

 background:
 linear-gradient(rgba(255,255,255,0.75), rgba(255,255,255,0.75)),
 url('/library/images/1588151545phpSWUpWe.jpeg');

 background-repeat:no-repeat;
 background-position:center;
 background-size:450px;
 background-attachment:fixed;
}

.header{
 background:#c62828;
 color:white;
 padding:15px 25px;
 font-size:20px;
}

.sidebar{
 width:220px;
 height:100vh;
 background:#d32f2f;
 color:white;
 position:fixed;
 top:50px;
}

.sidebar a{
 display:block;
 padding:15px;
 color:white;
 text-decoration:none;
}

.sidebar a:hover{
 background:#b71c1c;
}

.main{
 margin-left:220px;
 margin-top:50px;
 padding:30px;
}

.card{
 background:white;
 padding:20px;
 margin:15px;
 border-radius:10px;
 box-shadow:0 0 10px rgba(0,0,0,0.15);
 display:inline-block;
 width:220px;
 text-align:center;
}
</style>
</head>

<body>

<div class="header">
👨‍💼 Admin Panel — Suryadatta Library
</div>

<div class="sidebar">
<a href="dashboard.php">🏠 Dashboard</a>
<a href="requests.php">📥 Book Requests</a>
<a href="return_requests.php">📤 Return Requests</a>
<a href="manage_books.php">📚 Manage Books</a>
<a href="issued_books.php">📖 Issued Books</a>
<a href="students.php">👨‍🎓 Students</a>
<a href="payment_requests.php">💰 Manage Payments</a>
<a href="notices.php">📢 Notices</a>
<a href="../index.php">🚪 Logout</a>
</div>

<div class="main">

<h1>Welcome Admin 👋</h1>

<div class="card">
<h3>📥 Book Requests</h3>
<p>Approve or Reject</p>
</div>

<div class="card">
<h3>📤 Return Requests</h3>
<p>Approve Returns</p>
</div>

<div class="card">
<h3>📚 Books</h3>
<p>Add / Delete</p>
</div>

<div class="card">
<h3>📖 Issued</h3>
<p>Track Books</p>
</div>

<div class="card">
<h3>💰 Payments</h3>
<p>Manage Transactions</p>
</div>

<div class="card">
<h3>💵 Total Collected</h3>
<h2>₹<?php echo $total; ?></h2>
</div>

<div class="card">
<h3>⏳ Pending Amount</h3>
<h2>₹<?php echo $pending; ?></h2>
</div>

</div>

</body>
</html>